# AUTO GENERATED FILE - DO NOT EDIT

import typing  # noqa: F401
from typing_extensions import TypedDict, NotRequired, Literal # noqa: F401
from dash.development.base_component import Component, _explicitize_args

ComponentType = typing.Union[
    str,
    int,
    float,
    Component,
    None,
    typing.Sequence[typing.Union[str, int, float, Component, None]],
]

NumberType = typing.Union[
    typing.SupportsFloat, typing.SupportsInt, typing.SupportsComplex
]


class DashTree(Component):
    """A DashTree component.
DashTree is an svg tree hierarchy components.
It takes a json dataset, `data`, and
displays it in a collapsible tree.
It renders an svg with zoom, pan, and drag
behaviours.

Keyword arguments:

- id (string; default 'd3-tree'):
    The ID used to identify this component in Dash callbacks.

- activeNode (string; optional):
    The node selected, indicating a taxon of current focus.

- collapse (string; default "order"):
    Which level to collapse.

- data (dict; default { name: 'Loading...', children: [] }):
    The data used to create the tree viz."""
    _children_props = []
    _base_nodes = ['children']
    _namespace = 'dash_tree'
    _type = 'DashTree'


    def __init__(
        self,
        activeNode: typing.Optional[str] = None,
        collapse: typing.Optional[str] = None,
        data: typing.Optional[dict] = None,
        id: typing.Optional[typing.Union[str, dict]] = None,
        **kwargs
    ):
        self._prop_names = ['id', 'activeNode', 'collapse', 'data']
        self._valid_wildcard_attributes =            []
        self.available_properties = ['id', 'activeNode', 'collapse', 'data']
        self.available_wildcard_properties =            []
        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs and excess named props
        args = {k: _locals[k] for k in _explicit_args}

        super(DashTree, self).__init__(**args)

setattr(DashTree, "__init__", _explicitize_args(DashTree.__init__))
